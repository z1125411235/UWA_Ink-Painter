// -----------------------------------------------------------------------
// InkPainter
// Version 1.0.0
// -----------------------------------------------------------------------

InkPainter possible to paint object in runtime.
By using InkPainter, you can make in various special directing becomes possible.


■ How to use

Please refer to [https://esprogram.github.io/InkPainterDocument/].


■ Version History

1.0.0
   - Initial version